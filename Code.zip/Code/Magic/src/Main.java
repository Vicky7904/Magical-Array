import java.util.Random;

class Player {
    private int health;
    private int strength;
    private int attack;

    public Player(int health, int strength, int attack) {
        this.health = health;
        this.strength = strength;
        this.attack = attack;
    }

    public boolean isAlive() {
        return health > 0;
    }

    public void attack(Player opponent) {
        Random rand = new Random();
        int attackRoll = rand.nextInt(6) + 1;
        int damage = attackRoll * attack;

        opponent.defend(damage);
    }

    private void defend(int damage) {
        Random rand = new Random();
        int defendRoll = rand.nextInt(6) + 1;
        int defense = defendRoll * strength;

        int damageTaken = Math.max(0, damage - defense);
        health -= damageTaken;
    }
}

class Arena {
    public static void fight(Player player1, Player player2) {
        Player attacker = player1;
        Player defender = player2;

        while (player1.isAlive() && player2.isAlive()) {
            attacker.attack(defender);

            // Swap roles for the next round
            Player temp = attacker;
            attacker = defender;
            defender = temp;
        }

        if (player1.isAlive()) {
            System.out.println("Player 1 wins!");
        } else {
            System.out.println("Player 2 wins!");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Player player1 = new Player(50, 5, 10);
        Player player2 = new Player(100, 10, 5);

        Arena.fight(player1, player2);
    }
}